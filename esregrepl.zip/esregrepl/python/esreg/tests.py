"""
Specification tests after the ESR (Section 4 of the esreg paper).

wald_kappa_x(r)  -- constant selection on gains:  H0: kappa(x) = kappa.
    two-step route (kappa(x) = W(t1 - t0)):  H0: (t1 - t0)_{-1} = 0, exact null;
    FIML with hetsigma/hetrho:                H0: all non-constant coefficients of
        ln sigma_j and atanh rho_j are zero (homogeneous regime laws), a
        sufficient condition for kappa(x) constant.
Returns dict(chi2, df, p, slopes, se_slopes, names).
"""
import numpy as np
from scipy.stats import chi2


def wald_kappa_x(r):
    fit = r.fit
    th, V = fit["theta"], fit["V"]
    lay = fit["layout"]
    if fit["method"] == "twostep":
        pk = lay.pk
        if pk < 2:
            raise ValueError("no kappa() variables: nothing to test")
        i1 = np.arange(lay.t1.start, lay.t1.stop - 1)      # non-constant entries of t1
        i0 = np.arange(lay.t0.start, lay.t0.stop - 1)
        R = np.zeros((pk - 1, len(th)))
        R[np.arange(pk - 1), i1] = 1.0
        R[np.arange(pk - 1), i0] = -1.0
        names = [n.split("lambda1*")[1] for n in r.names if "lambda1*" in n][:-1]
    else:
        ps, pr = lay.ps, lay.pr
        idx = []
        for sl, p in ((lay.a1, ps), (lay.a0, ps), (lay.c1, pr), (lay.c0, pr)):
            idx += list(range(sl.start, sl.stop - 1))
        if not idx:
            raise ValueError("no hetsigma()/hetrho() variables: nothing to test")
        R = np.zeros((len(idx), len(th)))
        R[np.arange(len(idx)), idx] = 1.0
        names = [r.names[i] for i in idx]
    d = R @ th
    Vd = R @ V @ R.T
    W = float(d @ np.linalg.solve(Vd, d))
    df = R.shape[0]
    return dict(chi2=W, df=df, p=chi2.sf(W, df), slopes=d, se_slopes=np.sqrt(np.diag(Vd)), names=names)


def wald_sufficiency(df, y, x, d, z, keep=None, weights=None):
    """
    Index sufficiency (Section 4.2):  H0: E[omega_j | X, Z, u] = E[omega_j | X, u].
    The excluded instruments other than `keep` (default: the strongest in the
    probit) are added to the regime regressions of the two-step route; under H0
    their coefficients are zero in both regimes.  Wald on the stacked variance,
    joint over the two regimes; also each regime separately.
    Returns dict(chi2, df, p, chi2_1, df_1, p_1, chi2_0, df_0, p_0, tested, keep, coefs, se).
    """
    from .api import esreg
    from .probit import fit_probit
    import numpy as np
    from scipy.stats import chi2 as _chi2
    excl = [v for v in z if v not in x]
    if len(excl) == 0:
        raise ValueError("no excluded instrument in z")
    if keep is None:
        Z = np.c_[df[list(z)].to_numpy(float), np.ones(len(df))]
        dv = df[d].to_numpy() > 0
        w = df[weights].to_numpy(float) if weights else None
        pr = fit_probit(Z, dv, w)
        g, V = pr["gamma"], pr["V"]
        stats = {v: (g[list(z).index(v)] ** 2) / V[list(z).index(v), list(z).index(v)] for v in excl}
        keep = max(stats, key=stats.get)
    tested = [v for v in excl if v != keep]
    if len(tested) == 0:
        # single instrument: identification by the curvature of lambda alone
        tested = [keep]
        keep = None
    r = esreg(df, y, list(x) + tested, d, list(z), method="twostep", weights=weights)
    lay = r.fit["layout"]
    th, V = r.fit["theta"], r.fit["V"]
    k = len(x) + len(tested) + 1
    i1 = [lay.b1.start + len(x) + j for j in range(len(tested))]
    i0 = [lay.b0.start + len(x) + j for j in range(len(tested))]
    def wald(idx):
        R = np.zeros((len(idx), len(th))); R[np.arange(len(idx)), idx] = 1.0
        dlt = R @ th; Vd = R @ V @ R.T
        W = float(dlt @ np.linalg.solve(Vd, dlt)); return W, len(idx), _chi2.sf(W, len(idx))
    W, dfree, p = wald(i1 + i0)
    W1, d1, p1 = wald(i1)
    W0, d0, p0 = wald(i0)
    return dict(chi2=W, df=dfree, p=p, chi2_1=W1, df_1=d1, p_1=p1, chi2_0=W0, df_0=d0, p_0=p0,
                tested=tested, keep=keep, coefs=th[i1 + i0], se=np.sqrt(np.diag(V))[i1 + i0], fit=r)


def wald_hermite(df, y, x, d, z, weights=None, order=2):
    """
    Linearity of E[omega_j | u] in u (Assumption A2, Section 4.5).  The Hermite
    controls E[u^2 - 1 | D, Z] and E[u^3 - 3u | D, Z] are added beside the Mills
    ratio in each regime; under A2 their coefficients are zero.  Wald on the
    stacked variance, joint and by regime.  order = 1 (quadratic only) or 2.
    """
    from .api import esreg
    import numpy as np
    from scipy.stats import chi2 as _chi2
    r = esreg(df, y, list(x), d, list(z), method="twostep", weights=weights, hermite=order)
    lay = r.fit["layout"]; th, V = r.fit["theta"], r.fit["V"]
    i1 = list(range(lay.h1.start, lay.h1.stop)); i0 = list(range(lay.h0.start, lay.h0.stop))
    def wald(idx):
        R = np.zeros((len(idx), len(th))); R[np.arange(len(idx)), idx] = 1.0
        dlt = R @ th; Vd = R @ V @ R.T
        W = float(dlt @ np.linalg.solve(Vd, dlt)); return W, len(idx), _chi2.sf(W, len(idx))
    W, dfree, p = wald(i1 + i0); W1, d1, p1 = wald(i1); W0, d0, p0 = wald(i0)
    return dict(chi2=W, df=dfree, p=p, chi2_1=W1, df_1=d1, p_1=p1, chi2_0=W0, df_0=d0, p_0=p0,
                coefs=th[i1 + i0], se=np.sqrt(np.diag(V))[i1 + i0], fit=r)


def hausman_normal(df, y, x, d, z, weights=None):
    """
    FIML against two-step (Assumption A3, Section 4.5): Hausman contrast on the
    common parameters q = (gamma, beta_1, rho1 sigma1, beta_0, rho0 sigma0) with the
    covariance of the difference built from the influence functions of the two
    estimators (always positive semi-definite, valid under H0 and H1).
    Returns chi2, df, p on q, and the kappa contrast (kappa_2S - kappa_FIML) with
    its standard error.
    """
    from .api import esreg
    import numpy as np
    from scipy.stats import chi2 as _chi2, norm as _norm
    rF = esreg(df, y, list(x), d, list(z), method="fiml", weights=weights)
    rS = esreg(df, y, list(x), d, list(z), method="twostep", weights=weights)
    fF, fS = rF.fit, rS.fit
    layF, layS = fF["layout"], fS["layout"]
    k, m = layF.k, layF.m
    # influence functions: psi_i (n x p) with theta_hat - theta ~ mean(psi_i)
    psiF = fF["scores"] @ fF["V_oim"]                 # theta_F - theta ~ sum_i s_i (-H)^{-1}
    psiS = -(fS["moments"] @ fS["Ginv"].T)            # theta_S - theta ~ -Jac^{-1} sum_i g_i
    # q from FIML: (g, b1, tanh(c1)exp(a1), b0, tanh(c0)exp(a0)); Jacobian rows
    thF = fF["theta"]
    a1, a0, c1, c0 = thF[layF.a1][0], thF[layF.a0][0], thF[layF.c1][0], thF[layF.c0][0]
    rs1, rs0 = np.tanh(c1) * np.exp(a1), np.tanh(c0) * np.exp(a0)
    qdim = m + 2 * k + 2
    JF = np.zeros((qdim, layF.p)); JS = np.zeros((qdim, layS.p))
    r = 0
    for j in range(m): JF[r, layF.g.start + j] = 1; JS[r, layS.g.start + j] = 1; r += 1
    for j in range(k): JF[r, layF.b1.start + j] = 1; JS[r, layS.b1.start + j] = 1; r += 1
    JF[r, layF.c1.start] = (1 - np.tanh(c1) ** 2) * np.exp(a1); JF[r, layF.a1.start] = rs1; JS[r, layS.t1.start] = 1; r += 1
    for j in range(k): JF[r, layF.b0.start + j] = 1; JS[r, layS.b0.start + j] = 1; r += 1
    JF[r, layF.c0.start] = (1 - np.tanh(c0) ** 2) * np.exp(a0); JF[r, layF.a0.start] = rs0; JS[r, layS.t0.start] = 1; r += 1
    thS = fS["theta"]
    qF = np.r_[thF[layF.g], thF[layF.b1], rs1, thF[layF.b0], rs0]
    qS = np.r_[thS[layS.g], thS[layS.b1], thS[layS.t1], thS[layS.b0], thS[layS.t0]]
    D = JS @ psiS.T - JF @ psiF.T                     # qdim x n, influence of q_S - q_F
    VD = D @ D.T
    diff = qS - qF
    W = float(diff @ np.linalg.pinv(VD) @ diff)
    dfree = int(np.linalg.matrix_rank(VD))
    # kappa contrast
    Lk = np.zeros(qdim); Lk[m + k] = 1; Lk[m + 2 * k + 1] = -1
    kdiff = Lk @ diff; kse = np.sqrt(Lk @ VD @ Lk)
    return dict(chi2=W, df=dfree, p=_chi2.sf(W, dfree), q_2s=qS, q_fiml=qF, V_diff=VD,
                kappa_2s=Lk @ qS, kappa_fiml=Lk @ qF, kappa_diff=kdiff, kappa_se=kse,
                kappa_z=kdiff / kse, kappa_p=2 * _norm.sf(abs(kdiff / kse)), rF=rF, rS=rS)


def pseudo_did(df, y, x, d, z, nq=2, weights=None):
    """
    Pseudo-DiD on the selection index (Section 4.6).  Strata of the probit
    index v = Z gamma (nq quantile groups); within each stratum the X-adjusted
    gap between treated and untreated; the within-treated contrast C1 (top vs
    bottom stratum, X-adjusted) has expectation rho1 sigma1 (lam1_top - lam1_bot),
    the within-untreated contrast C0 has expectation -rho0 sigma0 (lam0_top -
    lam0_bot).  Signs are model-free under A2 with any monotone E[u | u > c];
    kappa_dd = C1 / dlam1 + C0 / dlam0 uses the Mills factors (A1) and needs no
    trivariate normality.  Returns the stratum table and the contrasts with
    standard errors (first-step variation of gamma ignored).
    """
    import numpy as np
    from scipy.stats import norm
    from .probit import fit_probit
    from .twostep import mills
    n = len(df)
    dv = df[d].to_numpy() > 0
    w = df[weights].to_numpy(float) if weights else np.ones(n)
    X = np.c_[df[list(x)].to_numpy(float), np.ones(n)]
    Z = np.c_[df[list(z)].to_numpy(float), np.ones(n)]
    yv = df[y].to_numpy(float)
    g = fit_probit(Z, dv, w)["gamma"]
    v = Z @ g
    l1, l0 = mills(v)
    # strata as Stata's xtile: cutpoints = pctile (average of the two order statistics
    # when n*p is an integer), values equal to a cutpoint go to the lower stratum
    vs = np.sort(v); n = len(v)
    def _pctile(p):
        r = n * p; k = int(np.floor(r))
        return (vs[k - 1] + vs[k]) / 2 if r == k else vs[k]
    cuts = np.array([_pctile(q / nq) for q in range(1, nq)])
    s = np.sum(v[:, None] > cuts[None, :], axis=1)
    def wls(yy, XX, ww):
        sw = np.sqrt(ww)
        A = XX * sw[:, None]; b = np.linalg.lstsq(A, yy * sw, rcond=None)[0]
        e = yy - XX @ b
        Vb = np.linalg.inv(A.T @ A) * np.sum(ww * e ** 2) / (len(yy) - XX.shape[1])
        return b, np.sqrt(np.diag(Vb))
    rows = []
    for q in range(nq):
        m = s == q
        b, se = wls(yv[m], np.c_[X[m], dv[m].astype(float)], w[m])
        rows.append(dict(stratum=q + 1, n1=int(dv[m].sum()), n0=int((~dv[m]).sum()),
                         v_mean=np.average(v[m], weights=w[m]), p_mean=np.average(norm.cdf(v[m]), weights=w[m]),
                         gap=b[-1], se_gap=se[-1],
                         lam1=np.average(l1[m & dv], weights=w[m & dv]), lam0=np.average(l0[m & ~dv], weights=w[m & ~dv])))
    top, bot = s == nq - 1, s == 0
    # within-treated contrast: Y on X and top-dummy among treated in the two extreme strata
    mt = dv & (top | bot)
    b1, se1 = wls(yv[mt], np.c_[X[mt], top[mt].astype(float)], w[mt])
    mu = (~dv) & (top | bot)
    b0, se0 = wls(yv[mu], np.c_[X[mu], top[mu].astype(float)], w[mu])
    C1, seC1, C0, seC0 = b1[-1], se1[-1], b0[-1], se0[-1]
    dlam1 = rows[-1]["lam1"] - rows[0]["lam1"]
    dlam0 = rows[-1]["lam0"] - rows[0]["lam0"]
    rs1 = C1 / dlam1; rs0 = -C0 / dlam0
    kappa_dd = rs1 - rs0
    se_kdd = np.sqrt((seC1 / dlam1) ** 2 + (seC0 / dlam0) ** 2)
    dd = rows[-1]["gap"] - rows[0]["gap"]
    se_dd = np.sqrt(rows[-1]["se_gap"] ** 2 + rows[0]["se_gap"] ** 2)
    return dict(table=rows, C1=C1, se_C1=seC1, C0=C0, se_C0=seC0, dlam1=dlam1, dlam0=dlam0,
                rhosig1=rs1, rhosig0=rs0, kappa_dd=kappa_dd, se_kappa_dd=se_kdd,
                dd=dd, se_dd=se_dd, nq=nq)


def link_test(df, d, z, order=2, add=None, weights=None):
    """
    Specification of the selection index (Section 4.1), on the probit alone.
    Default (add=None): Pregibon-type link test.  v = Z gamma_hat from the probit
    of D on Z; a second probit of D on (v, v^2, ..., v^order); H0: the coefficients
    of the powers 2..order are zero.  Wald chi2(order - 1) on the observed
    information.  Rejection: the index is not linear in Z (missing polynomials or
    interactions) or the link is not the normal cdf.
    add = list of columns: RESET-type variant.  The probit of D on Z and the added
    terms; H0: their coefficients are zero.  Wald chi2(#add) and the LR test of
    the nested probits.
    Returns dict(chi2, df, p, coefs, se, names[, lr, p_lr, ll_full, ll_restr]).
    """
    from .api import _design
    from .probit import fit_probit
    from scipy.stats import chi2 as _chi2
    n = len(df)
    w = np.ones(n) if weights is None else df[weights].to_numpy(float)
    dd = df[d].to_numpy(bool)
    Z = _design(df, list(z))
    pr = fit_probit(Z, dd, w)
    if add is None:
        v = Z @ pr["gamma"]
        Zl = np.c_[np.column_stack([v ** j for j in range(1, order + 1)]), np.ones(n)]
        fl = fit_probit(Zl, dd, w)
        idx = list(range(1, order))
        names = [f"v^{j + 1}" for j in idx]
        coefs, V = fl["gamma"], fl["V"]
        out = dict(v_coef=fl["gamma"][0], v_se=np.sqrt(fl["V"][0, 0]))
    else:
        Zf = np.c_[Z[:, :-1], df[list(add)].to_numpy(float), np.ones(n)]
        fl = fit_probit(Zf, dd, w)
        idx = list(range(len(z), len(z) + len(add)))
        names = list(add)
        coefs, V = fl["gamma"], fl["V"]
        lr = 2 * (fl["ll"] - pr["ll"])
        out = dict(lr=lr, p_lr=_chi2.sf(lr, len(add)), ll_full=fl["ll"], ll_restr=pr["ll"])
    b = coefs[idx]
    Vb = V[np.ix_(idx, idx)]
    W = float(b @ np.linalg.solve(Vb, b))
    out.update(chi2=W, df=len(idx), p=_chi2.sf(W, len(idx)), coefs=b, se=np.sqrt(np.diag(Vb)),
               names=names, gamma=pr["gamma"])
    return out


def gamma_contrast(df, y, x, d, z, weights=None):
    """
    What trivariate normality imposes on the selection equation (Section 4.1):
    the gamma block of the Hausman contrast of hausman_normal.  The probit
    estimate of gamma is consistent under A1 alone; the FIML estimate uses the
    outcomes through the correlations and is consistent under A1-A3.  H0: A3;
    Wald chi2 on the gamma block of the influence-function covariance of the
    difference.  Returns dict(chi2, df, p, g_probit, g_fiml, diff, se_diff, hausman).
    """
    from scipy.stats import chi2 as _chi2
    h = hausman_normal(df, y, x, d, z, weights=weights)
    m = h["rF"].fit["layout"].m
    diff = (h["q_2s"] - h["q_fiml"])[:m]
    VD = h["V_diff"][:m, :m]
    W = float(diff @ np.linalg.pinv(VD) @ diff)
    dfree = int(np.linalg.matrix_rank(VD))
    return dict(chi2=W, df=dfree, p=_chi2.sf(W, dfree), g_probit=h["q_2s"][:m], g_fiml=h["q_fiml"][:m],
                diff=diff, se_diff=np.sqrt(np.diag(VD)), hausman=h)
