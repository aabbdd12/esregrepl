* esrmte_test.do -- step 2c: esrmte (parametric MTE line + semiparametric PWR curve)
* against msat's mte()/semipar and the msat note, Table 8.  Run from the project
* root: run_stata.bat stata\esrmte_test.do
version 16
clear all
set more off
foreach f in esreg esreg_lf1 esreg_engine esreg_mata _esreg_getest _esreg_data _esreg_effects_post esreg_p esrcurve esrmte _esreg_pwr {
    cap confirm file "`f'.ado"
    if (_rc == 0) run "`f'.ado"
    else          run "stata/`f'.ado"
}

* ---- 1. parametric line, FIML on esr_sim: msat gave 2.3004 (0.0675) 1.9047 (0.0554)
*         1.2435 (0.0374) 0.5088 (0.0275) -0.2258 (0.0370) -0.8870 (0.0549) -1.2827 (0.0670)
use "data/esr_sim.dta", clear
esreg y x, select(d = x z) nolog
esrmte
matrix list r(mte)

* the same after movestay + msat, for a side-by-side check
movestay y x, select(d = x z)
msat d, mte(.05 .1 .25 .5 .75 .9 .95)

* ---- 2. two-step + semipar on the three samples (note, Table 8) --------------------
* expected on esr_sim: two-step line 1.62 0.99 0.32 -0.37 -0.97 ;
*   PWR 1.92 (0.19) 1.10 (0.09) 0.30 (0.06) -0.49 (0.11) -0.85 (0.12) ; h .08 .08 .11 .11 .30
use "data/esr_sim.dta", clear
esreg y x, select(d = x z) method(twostep) nolog
esrmte, at(.1 .25 .5 .75 .9) semipar graph name(mte_sim)
matrix list r(mte_sp)

* expected on esr_skew: two-step line 1.71 ... ; PWR 2.18 (0.25) at tau = .10 (Table 8)
use "data/esr_skew.dta", clear
esreg y x, select(d = x z) method(twostep) nolog
esrmte, at(.1 .25 .5 .75 .9) semipar graph name(mte_skew)

* expected on esr_nonlin: PWR flat near 0.5 over the first half, falling afterwards
use "data/esr_nonlin.dta", clear
esreg y x, select(d = x z) method(twostep) nolog
esrmte, at(.1 .25 .5 .75 .9) semipar graph name(mte_nonlin)

* ---- 3. e() is left untouched by esrmte (probit and _esreg_pwr run inside) ------------
esrmte, at(.5) semipar
di as txt "e(cmd) after esrmte: " as res "`e(cmd)'" as txt "   e(att) = " as res e(att) as txt "  (expected esreg, 1.08803)"
* and est() from a stored estimation after another command
use "data/esr_sim.dta", clear
esreg y x, select(d = x z) store(fiml) nolog
regress y x
esrmte, est(fiml) at(.25 .5 .75)
