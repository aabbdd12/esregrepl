* esreg_net_test.do -- install esreg from GitHub and run the quick start of the README
cap ado uninstall esreg
net install esreg, from("https://raw.githubusercontent.com/aabbdd12/esreg/main/") replace
ado describe esreg
which esreg
which esreg_engine
which esreg_mata
which _esreg_getest
use "data/union3.dta", clear
esreg ln_wage age grade smsa black tenure, select(union = south black tenure) nolog
esreg ln_wage age grade smsa black tenure, select(union = south black tenure) method(twostep) nolog
esrdiag
esrtest, spec
esrtest, normal
esrtest, pdid nq(4)
predict double p, pr
esrcurve, rank(p) nq(5)
esrmte, semipar
esrreport
di as txt _n "expected: ATT .387122 (fiml) and 1.09796 (twostep); kappa .210207; route twostep"
