* esreg_dlg_test.do -- checks that go with the new dialog box esreg.dlg:
*   (1) the by: prefix, now that esreg is declared byable(recall);
*   (2) every command line the dialog can build, typed by hand (a .dlg cannot
*       be exercised in batch mode; only -db esreg- opens it).
* Run:  run_stata.bat stata\esreg_dlg_test.do

version 16
clear all
set more off

foreach f in esreg esreg_lf1 esreg_engine esreg_mata _esreg_getest _esreg_data _esreg_effects_post {
    cap confirm file "`f'.ado"
    if (_rc == 0) run "`f'.ado"
    else          run "stata/`f'.ado"
}

* ---- 0. is the dialog file on the adopath? -------------------------------
cap findfile esreg.dlg
if (_rc == 0) di as txt _n "esreg.dlg found: " as res "`r(fn)'"
else          di as err _n "esreg.dlg not on the adopath (copy stata\esreg.dlg beside esreg.ado)"

* ---- 1. by: prefix -------------------------------------------------------
use "data/union3.dta", clear
di as txt _n "{hline 70}" _n "1. by: prefix (byable(recall))" _n "{hline 70}"
bysort smsa: esreg wage age grade tenure, ///
    select(union = south black tenure) nolog
di as txt _n "  last group shown above (smsa = 1): e(N) = " as res e(N)

* ---- 2. the command lines the dialog builds ------------------------------
use "data/union3.dta", clear
di as txt _n "{hline 70}" _n "2a. FIML, defaults" _n "{hline 70}"
esreg wage age grade smsa black tenure, ///
    select(union = south black tenure) nolog

di as txt _n "{hline 70}" _n "2b. FIML, vce(robust), level(90), store(m1)" _n "{hline 70}"
esreg wage age grade smsa black tenure, ///
    select(union = south black tenure) vce(robust) level(90) store(m1) nolog

di as txt _n "{hline 70}" _n "2c. FIML, vce(cluster idcode), iterate(50), difficult" _n "{hline 70}"
cap confirm variable idcode
if (_rc == 0) {
    esreg wage age grade smsa black tenure, ///
        select(union = south black tenure) vce(cluster idcode) ///
        iterate(50) difficult nolog
}
else {
    di as txt "  (no idcode in union3: clustering on smsa instead)"
    esreg wage age grade black tenure, ///
        select(union = south black tenure) vce(cluster smsa) ///
        iterate(50) difficult nolog
}

di as txt _n "{hline 70}" _n "2d. FIML, hetsigma() and hetrho()" _n "{hline 70}"
esreg wage age grade smsa black tenure, ///
    select(union = south black tenure) hetsigma(grade) hetrho(grade) nolog

di as txt _n "{hline 70}" _n "2e. two-step, kappa(grade)" _n "{hline 70}"
esreg wage age grade smsa black tenure, ///
    select(union = south black tenure) method(twostep) kappa(grade)

di as txt _n "{hline 70}" _n "2f. two-step, hermite" _n "{hline 70}"
esreg wage age grade smsa black tenure, ///
    select(union = south black tenure) method(twostep) hermite

di as txt _n "{hline 70}" _n "2g. pweight, hsize(), noeffects, nosvyset" _n "{hline 70}"
cap confirm file "data/esr_wt.dta"
if (_rc == 0) {
    use "data/esr_wt.dta", clear
    esreg income educ [pw = wt], select(treatment = educ i.region inst) ///
        hsize(hsize) noeffects nosvyset nolog
}
else di as txt "  (data/esr_wt.dta absent: step skipped)"

di as txt _n "{hline 70}" _n "esreg_dlg_test.do finished" _n "{hline 70}"
