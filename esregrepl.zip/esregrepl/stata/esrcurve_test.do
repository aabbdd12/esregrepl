* esrcurve_test.do -- step 2b: predict (esreg_p) and esrcurve against mspredict,
* msat and the paper's Table 4 (deciles of x on esr_sim).  Run from the folder
* that contains data/ (sogrepl) with the ado files in the folder or in stata/.
version 16
clear all
set more off
foreach f in esreg esreg_lf1 esreg_engine esreg_mata _esreg_getest _esreg_data _esreg_effects_post esreg_p esrcurve {
    cap confirm file "`f'.ado"
    if (_rc == 0) run "`f'.ado"
    else          run "stata/`f'.ado"
}

use "data/esr_sim.dta", clear

* ---- reference: movestay + mspredict + msat -----------------------------------
movestay y x, select(d = x z)
mspredict m_p,   psel
mspredict m_xb1, xb1
mspredict m_xb0, xb2
mspredict m_l1,  mills1
mspredict m_l0,  mills2
mspredict m_yc11, yc1_1
mspredict m_yc01, yc2_1
mspredict m_yc10, yc1_2
mspredict m_yc00, yc2_2
msat d, generate(m_eff) pscore(m_pz) rank(x) nq(10)
cap matrix MSAT = r(curve)

* ---- esreg + predict --------------------------------------------------------------
esreg y x, select(d = x z) nolog
predict e_p,   pr
predict e_xb1, xb1
predict e_xb0, xb0
predict e_l1,  lambda1
predict e_l0,  lambda0
predict e_yc11, yc11
predict e_yc01, yc01
predict e_yc10, yc10
predict e_yc00, yc00
predict e_eff, effect
predict e_kap, kappa

di as txt _n "max |esreg predict - mspredict/msat| (should be ~1e-6, the two maximizers stop at slightly different points):"
foreach v in p xb1 xb0 l1 l0 eff {
    qui gen double diff_`v' = abs(e_`v' - m_`v')
    qui summarize diff_`v'
    di as txt %6s "`v'" as res %12.3e r(max)
}
foreach v in yc11 yc01 {
    qui gen double diff_`v' = abs(e_`v' - m_`v') if d == 1
    qui summarize diff_`v'
    di as txt %6s "`v'" as res %12.3e r(max) as txt "  (treated)"
}
foreach v in yc10 yc00 {
    qui gen double diff_`v' = abs(e_`v' - m_`v') if d == 0
    qui summarize diff_`v'
    di as txt %6s "`v'" as res %12.3e r(max) as txt "  (untreated)"
}
qui summarize e_kap
di as txt "kappa_i (constant here): " as res r(mean) as txt "   e(kappa) = " as res e(kappa)

* ---- esrcurve against msat's Table 4 -------------------------------------------------
esrcurve, rank(x) nq(10)
matrix ESR = r(table)
di as txt _n "expected (msat, paper A Table 4), treated column: -0.1598 (0.0459) 0.3490 (0.0397) 0.6038 (0.0373) ..."
di as txt "   ... 1.8210 (0.0385) 2.3502 (0.0450); untreated: -1.4770 (0.0481) ... 0.9567 (0.0522); all: -0.9152 (0.0425) ... 1.9342 (0.0426)"
cap noisily matrix list MSAT

* ---- est() and the automatic store: two-step curve on the same base --------------------
esreg y x, select(d = x z) method(twostep) store(ts) nolog
regress y x
esrcurve, rank(x) nq(5) est(ts)
esrcurve, rank(x) nq(5)              // falls back to _esreg (the two-step)
esrcurve, rank(x) nq(10) graph name(curve10)
