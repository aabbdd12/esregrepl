"""
Treatment effects after the ESR (either route): the four conditional
expectations, ATT / ATU / ATE, kappa, delta-method standard errors on the
estimated parameter covariance plus the sampling component of the averaged
individual effects, and the common support of P(Z).
"""
import numpy as np
from scipy.stats import norm
from .twostep import mills


def _components(th, fit, X, Z, d):
    lay = fit["layout"]
    if fit["method"] == "fiml":
        b1, b0, g, a1, a0, c1, c0 = lay.unpack(th)
        s1, s0 = np.exp(fit["Ws"] @ a1), np.exp(fit["Ws"] @ a0)
        r1, r0 = np.tanh(fit["Wr"] @ c1), np.tanh(fit["Wr"] @ c0)
        kap_i = r1 * s1 - r0 * s0
    else:
        g, b1, t1, b0, t0 = th[lay.g], th[lay.b1], th[lay.t1], th[lay.b0], th[lay.t0]
        kap_i = fit["Wk"] @ (t1 - t0)
    zg = Z @ g
    l1, l0 = mills(zg)
    mg = X @ (b1 - b0)
    return b1, b0, g, kap_i, zg, l1, l0, mg


def individual_effects(th, fit, X, Z, d):
    b1, b0, g, kap_i, zg, l1, l0, mg = _components(th, fit, X, Z, d)
    dd = np.where(d, mg + kap_i * l1, mg - kap_i * l0)
    return dd, kap_i


def aggregate(th, fit, X, Z, d, w):
    dd, kap_i = individual_effects(th, fit, X, Z, d)
    att = np.average(dd[d], weights=w[d])
    atu = np.average(dd[~d], weights=w[~d])
    ate = np.average(dd, weights=w)
    kap = np.average(kap_i, weights=w)
    return np.array([att, atu, ate, kap]), dd


def treatment_effects(fit, X, Z, d, w=None, h=1e-6):
    n = len(d)
    w = np.ones(n) if w is None else np.asarray(w, float)
    th, V = fit["theta"], fit["V"]
    est, dd = aggregate(th, fit, X, Z, d, w)
    p = len(th)
    J = np.zeros((4, p))
    for i in range(p):
        e = np.zeros(p); e[i] = h
        J[:, i] = (aggregate(th + e, fit, X, Z, d, w)[0] - aggregate(th - e, fit, X, Z, d, w)[0]) / (2 * h)
    Vp = J @ V @ J.T
    # sampling component of the averaged individual effects (weighted)
    def wvar_mean(v, ww):
        mu = np.average(v, weights=ww)
        return np.sum((ww * (v - mu)) ** 2) / np.sum(ww) ** 2
    samp = np.array([wvar_mean(dd[d], w[d]), wvar_mean(dd[~d], w[~d]), wvar_mean(dd, w), 0.0])
    se = np.sqrt(np.diag(Vp) + samp)
    b1, b0, g, kap_i, zg, l1, l0, mg = _components(th, fit, X, Z, d)
    P = norm.cdf(zg)
    return dict(names=["ATT", "ATU", "ATE", "kappa"], est=est, se=se, z=est / se,
                var_param=np.diag(Vp), var_samp=samp, dd=dd, kappa_i=kap_i, P=P,
                support=(P[d].min(), P[d].max(), P[~d].min(), P[~d].max()),
                common_support=(max(P[d].min(), P[~d].min()), min(P[d].max(), P[~d].max())),
                mean_l1_treated=np.average(l1[d], weights=w[d]),
                mean_l0_untreated=np.average(l0[~d], weights=w[~d]))
