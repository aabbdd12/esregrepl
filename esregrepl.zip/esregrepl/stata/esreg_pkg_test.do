* esreg_pkg_test.do -- install the package from the project folder and exercise it
* (the help files are printed to the log, which checks their SMCL)
cap ado uninstall esreg
net install esreg, from("C:\Users\aabd\OneDrive\Desktop\esreg_project\package") replace
ado describe esreg
which esreg
which esreg_engine
which _esreg_getest
which _esreg_data
which esrreport
help esreg
help esreg_postestimation
help esrdiag
help esrtest
help esrcurve
help esrmte
help esrreport
* quick start with the installed commands (no run of the project's ado files)
use "data/union3.dta", clear
esreg ln_wage age grade smsa black tenure, select(union = south black tenure) nolog
esreg ln_wage age grade smsa black tenure, select(union = south black tenure) method(twostep) nolog
esrdiag
esrtest, spec
esrtest, pdid nq(4)
predict double p, pr
esrcurve, rank(p) nq(5)
esrmte
esrreport, notests
