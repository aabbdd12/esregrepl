* esrreport_test.do -- the reading command on the manual's example and on the validation samples
foreach f in esreg esreg_lf1 esreg_engine esreg_mata _esreg_getest _esreg_data _esreg_effects_post esreg_p esrdiag esrtest esrcurve esrreport {
    cap confirm file "`f'.ado"
    if (_rc == 0) run "`f'.ado"
    else          run "stata/`f'.ado"
}
* ---- union3, ln_wage: single dummy instrument, Hausman borderline -----------------------
use "data/union3.dta", clear
esreg ln_wage age grade smsa black tenure, select(union = south black tenure) nolog
esrreport, export("logs/reading_union3.txt") replace
return list
* ---- union3, wage in levels: skewed regime errors ----------------------------------------
esreg wage age grade smsa black tenure, select(union = south black tenure) method(twostep) nolog
esrreport
* ---- esr_sim: everything holds, kappa = 1.08 --------------------------------------------
use "data/esr_sim.dta", clear
esreg y x, select(d = x z) nolog
esrreport
* ---- esr_link: omitted quadratic in the index -------------------------------------------
use "data/esr_link.dta", clear
esreg y x, select(d = x z) method(twostep) nolog
esrreport
* ---- esr_dh: double hurdle, two instruments ---------------------------------------------
use "data/esr_dh.dta", clear
esreg y x, select(d = x z1 z2) method(twostep) nolog
esrreport
* ---- esr_annex2 with i.region, notests --------------------------------------------------
use "data/esr_annex2.dta", clear
esreg income educ, select(treatment = educ i.region inst) nolog
esrreport, notests
di as txt "e(cmd) after esrreport: `e(cmd)'  (expected esreg)"
