* esreg_dlg_probe.do -- verification of the three standard dialog includes used
* by stata\esreg.dlg (_std_large, header, _sp_level): are they present in THIS
* installation, and do they define every layout macro esreg.dlg refers to?
* Also puts stata\ on the adopath so that -db esreg- can find esreg.dlg.
* Run:  run_stata.bat stata\esreg_dlg_probe.do

version 16
clear all
set more off

di as txt _n "{hline 70}"
di as txt "Stata version " as res c(stata_version) as txt ", flavor " as res c(flavor) ///
          as txt ", born " as res c(born_date)
di as txt "{hline 70}"

* ---- 1. the include files ------------------------------------------------
foreach f in _std_large.idlg header.idlg _sp_level.idlg {
    cap findfile "`f'"
    if (_rc == 0) di as txt "`f' : " as res "`r(fn)'"
    else          di as err  "`f' : NOT FOUND"
}

* ---- 2. their content (the macros esreg.dlg uses must appear here) --------
foreach f in _std_large.idlg header.idlg _sp_level.idlg {
    cap findfile "`f'"
    if (_rc == 0) {
        di as txt _n "{hline 70}" _n "---- `f' ----" _n "{hline 70}"
        type "`r(fn)'"
    }
}

* ---- 3. is esreg.dlg reachable? ------------------------------------------
adopath + "stata"
cap findfile esreg.dlg
if (_rc == 0) di as txt _n "esreg.dlg : " as res "`r(fn)'"
else          di as err  _n "esreg.dlg : NOT FOUND on the adopath"

* ---- 4. try to open it (batch mode usually refuses; the message matters) --
di as txt _n "{hline 70}" _n "db esreg (the error below, if any, is informative)" _n "{hline 70}"
cap noisily db esreg
di as txt _n "return code = " as res _rc

di as txt _n "{hline 70}" _n "esreg_dlg_probe.do finished" _n "{hline 70}"
