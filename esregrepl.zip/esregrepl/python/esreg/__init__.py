"""esreg -- endogenous switching regression: FIML and two-step routes, effects, kappa.
Reference implementation for the Stata command esreg (version 0.1, September 2026)."""
from .api import esreg, Results
__version__ = "0.1.0"
