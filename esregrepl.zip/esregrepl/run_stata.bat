@echo off
rem run_stata.bat [dofile]  -- runs a do-file in batch from the project root.
rem A wrapper do-file cds to the root (profile.do may move away from it) and
rem opens logs\<name>.log explicitly, so the log lands there whatever Stata does.
cd /d "%~dp0"
set DOFILE=%1
if "%DOFILE%"=="" set DOFILE=stata\hello.do
for %%F in ("%DOFILE%") do set NAME=%%~nF
if not exist logs mkdir logs
> "_run.do" echo cd "%~dp0"
>> "_run.do" echo log using "logs\%NAME%.log", replace text
>> "_run.do" echo do "%DOFILE%"
>> "_run.do" echo log close
"C:\Program Files\StataNow19\StataBE-64.exe" /e do "%~dp0_run.do"
if exist "_run.log" del "_run.log"
if exist "_run.do" del "_run.do"
echo done: logs\%NAME%.log
