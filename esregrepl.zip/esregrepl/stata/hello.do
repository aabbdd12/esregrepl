* hello.do -- batch test: Stata is run by run_stata.bat from the project root
display "Hello World"
display "Stata " c(stata_version) " " c(edition_real) " on " c(current_date) " " c(current_time)
display "current directory: " c(pwd)
